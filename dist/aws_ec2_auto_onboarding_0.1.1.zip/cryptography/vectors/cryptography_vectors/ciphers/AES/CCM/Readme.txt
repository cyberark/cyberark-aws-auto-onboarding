There are two sets of CCM example files:

1. The response (.rsp) files contain properly formatted CAVS response files.

2. The three DVPT{128/192/256}.txt files contain the same values as the
   DVPT{128/192/256}.rsp files but have additional information.  For the cases
   that fail, the reason for failure is in parentheses following the result:
     e.g., Result = Fail (2 - CT changed)
   This additional information is not in properly formatted response files.
